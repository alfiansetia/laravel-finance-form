<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body style="align-content: center">
    <table>
        <tbody>
            <tr>
                <td colspan="9" width="666">
                    <p><sub>&shy;</sub></p>
                    <p><strong>PT. ESR INDONESIA
                            MANAGEMENT</strong><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        </strong><strong>PAYMENT REQUEST</strong></p>
                </td>
            </tr>
            <tr>
                <td width="83">
                    <p><strong>PAID TO : </strong></p>
                </td>
                <td width="24">
                    <p>&nbsp;</p>
                </td>
                <td width="90">
                    <p>&nbsp;</p>
                </td>
                <td width="93">
                    <p>&nbsp;</p>
                </td>
                <td width="26">
                    <p>&nbsp;</p>
                </td>
                <td width="90">
                    <p>&nbsp;</p>
                </td>
                <td width="97">
                    <p>&nbsp;</p>
                </td>
                <td width="62">
                    <p>NO</p>
                </td>
                <td width="101">
                    <p>01/EIM-PR/01/2024</p>
                </td>
            </tr>
            <tr>
                <td width="83">
                    <p><strong>user</strong></p>
                </td>
                <td width="24">
                    <p>&nbsp;</p>
                </td>
                <td width="90">
                    <p>&nbsp;</p>
                </td>
                <td width="93">
                    <p>&nbsp;</p>
                </td>
                <td width="26">
                    <p>&nbsp;</p>
                </td>
                <td width="90">
                    <p>&nbsp;</p>
                </td>
                <td width="97">
                    <p>&nbsp;</p>
                </td>
                <td width="62">
                    <p>DATE</p>
                </td>
                <td width="101">
                    <p>01-Jan-24</p>
                </td>
            </tr>
            <tr>
                <td colspan="9" width="666">
                    <p><strong>FOR : 1</strong></p>
                </td>
            </tr>
            <tr>
                <td colspan="8" width="565">
                    <p><strong>DESCRIPTION</strong></p>
                </td>
                <td width="101">
                    <p><strong>AMOUNT</strong></p>
                </td>
            </tr>
            <tr>
                <td colspan="8" width="565">
                    <p>&nbsp;coklat</p>
                </td>
                <td width="101">
                    <p>$100000</p>
                </td>
            </tr>
            <tr>
                <td colspan="8" width="565">
                    <p>&nbsp;&nbsp;</p>
                </td>
                <td width="101">
                    <p>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td colspan="8" width="565">
                    <p>&nbsp;&nbsp;</p>
                </td>
                <td width="101">
                    <p>&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td colspan="8" width="565">
                    <p>&nbsp;</p>
                </td>
                <td width="101">
                    <p>&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td colspan="8" width="565">
                    <p>&nbsp;</p>
                </td>
                <td width="101">
                    <p>&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td colspan="8" width="565">
                    <p>&nbsp;</p>
                </td>
                <td width="101">
                    <p>&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td colspan="8" width="565">
                    <p>&nbsp;</p>
                </td>
                <td width="101">
                    <p>&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td colspan="8" width="565">
                    <p>&nbsp;</p>
                </td>
                <td width="101">
                    <p>&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td colspan="8" width="565">
                    <p>&nbsp;</p>
                </td>
                <td width="101">
                    <p>&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td colspan="8" width="565">
                    <p>&nbsp;</p>
                </td>
                <td width="101">
                    <p>&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td colspan="8" width="565">
                    <p>&nbsp;</p>
                </td>
                <td width="101">
                    <p>&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td colspan="8" width="565">
                    <p>&nbsp;</p>
                </td>
                <td width="101">
                    <p>&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td colspan="8" width="565">
                    <p>&nbsp;</p>
                </td>
                <td width="101">
                    <p>&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td colspan="8" width="565">
                    <p>&nbsp;</p>
                </td>
                <td width="101">
                    <p>&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td colspan="8" width="565">
                    <p>&nbsp;</p>
                </td>
                <td width="101">
                    <p>&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td colspan="8" width="565">
                    <p>&nbsp;</p>
                </td>
                <td width="101">
                    <p>&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td colspan="8" width="565">
                    <p>&nbsp;</p>
                </td>
                <td width="101">
                    <p>&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td colspan="8" width="565">
                    <p>&nbsp;</p>
                </td>
                <td width="101">
                    <p>&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td colspan="8" width="565">
                    <p>&nbsp;</p>
                </td>
                <td width="101">
                    <p>&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td colspan="8" width="565">
                    <p>&nbsp;</p>
                </td>
                <td width="101">
                    <p>&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td width="83">
                    <p>&nbsp;</p>
                </td>
                <td width="24">
                    <p>&nbsp;</p>
                </td>
                <td width="90">
                    <p>&nbsp;</p>
                </td>
                <td width="93">
                    <p>&nbsp;</p>
                </td>
                <td width="26">
                    <p>&nbsp;</p>
                </td>
                <td width="90">
                    <p>&nbsp;</p>
                </td>
                <td width="97">
                    <p>&nbsp;</p>
                </td>
                <td width="62">
                    <p><strong>To be Paid </strong></p>
                </td>
                <td width="101">
                    <p><strong>$111000</strong></p>
                </td>
            </tr>
            <tr>
                <td width="83">
                    <p>&nbsp;</p>
                </td>
                <td width="24">
                    <p>&nbsp;</p>
                </td>
                <td width="90">
                    <p>&nbsp;</p>
                </td>
                <td width="93">
                    <p>&nbsp;</p>
                </td>
                <td width="26">
                    <p>&nbsp;</p>
                </td>
                <td width="90">
                    <p>&nbsp;</p>
                </td>
                <td width="97">
                    <p>&nbsp;</p>
                </td>
                <td width="62">
                    <p><strong>Forex at</strong></p>
                </td>
                <td width="101">
                    <p>&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td width="83">
                    <p>&nbsp;</p>
                </td>
                <td width="24">
                    <p>&nbsp;</p>
                </td>
                <td width="90">
                    <p>&nbsp;</p>
                </td>
                <td width="93">
                    <p>&nbsp;</p>
                </td>
                <td width="26">
                    <p>&nbsp;</p>
                </td>
                <td width="90">
                    <p>&nbsp;</p>
                </td>
                <td colspan="2" width="159">
                    <p><strong>Convert to</strong></p>
                </td>
                <td width="101">
                    <p>&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td width="83">
                    <p>&nbsp;</p>
                </td>
                <td width="24">
                    <p>&nbsp;</p>
                </td>
                <td width="90">
                    <p>&nbsp;</p>
                </td>
                <td width="93">
                    <p>&nbsp;</p>
                </td>
                <td width="26">
                    <p>&nbsp;</p>
                </td>
                <td width="90">
                    <p>&nbsp;</p>
                </td>
                <td colspan="2" width="159">
                    <p><strong>&nbsp;Bank Charges </strong></p>
                </td>
                <td width="101">
                    <p><strong>$</strong></p>
                </td>
            </tr>
            <tr>
                <td colspan="8" width="565">
                    <p><strong>TOTAL &nbsp;</strong></p>
                </td>
                <td width="101">
                    <p><strong>$111000</strong></p>
                </td>
            </tr>
            <tr>
                <td colspan="9" width="666">
                    <p>&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td colspan="3" width="197">
                    <p><strong><u>BANK ACCOUNT FROM </u></strong><strong>:</strong></p>
                </td>
                <td colspan="3" width="209">
                    <p><strong><u>TRANSFERRED TO BANK ACCOUNT </u></strong><strong>:</strong></p>
                </td>
                <td colspan="3" width="260">
                    <p><strong>CHECK SUPPORTING DOCUMENT</strong></p>
                </td>
            </tr>
            <tr>
                <td colspan="3" width="197">
                    <p>1</p>
                    <p>PT. ESR INDONESIA MANAGEMENT</p>
                </td>
                <td colspan="3" width="209">
                    <p>user</p>
                    <p>BRI</p>
                </td>
                <td width="97">
                    <p><strong>CONTRACT / PO No</strong></p>
                </td>
                <td colspan="2" width="163">
                    <p>&nbsp;${Contract+po}</p>
                </td>
            </tr>
            <tr>
                <td colspan="3" width="197">
                    <p>&nbsp;</p>
                </td>
                <td width="93">
                    <p>&nbsp;</p>
                </td>
                <td width="26">
                    <p>&nbsp;</p>
                </td>
                <td width="90">
                    <p>&nbsp;</p>
                </td>
                <td colspan="3" width="260">
                    <p>[&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ] ORIGINAL INVOICE + MATERAI</p>
                </td>
            </tr>
            <tr>
                <td colspan="3" width="197">
                    <p>&nbsp;</p>
                </td>
                <td width="93">
                    <p>&nbsp;</p>
                </td>
                <td width="26">
                    <p>&nbsp;</p>
                </td>
                <td width="90">
                    <p>&nbsp;</p>
                </td>
                <td colspan="2" width="159">
                    <p>[&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ] ORIGINAL FAKTUR PAJAK</p>
                </td>
                <td width="101">
                    <p>&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td colspan="3" width="197">
                    <p>&nbsp;</p>
                </td>
                <td width="93">
                    <p>&nbsp;</p>
                </td>
                <td width="26">
                    <p>&nbsp;</p>
                </td>
                <td width="90">
                    <p>&nbsp;</p>
                </td>
                <td colspan="3" width="260">
                    <p>[&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ] ORIGINAL DGT-1 WP LN ( Foreigner Consultant )</p>
                </td>
            </tr>
            <tr>
                <td colspan="3" width="197">
                    <p>&nbsp;</p>
                </td>
                <td width="93">
                    <p>&nbsp;</p>
                </td>
                <td width="26">
                    <p>&nbsp;</p>
                </td>
                <td width="90">
                    <p>&nbsp;</p>
                </td>
                <td colspan="2" width="159">
                    <p>[&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ] COPY OF NPWP</p>
                </td>
                <td width="101">
                    <p>&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td colspan="2" width="107">
                    <p>Paid by</p>
                </td>
                <td width="90">
                    <p>Internet Banking</p>
                </td>
                <td colspan="2" width="118">
                    <p>INVOICE DATE</p>
                </td>
                <td width="90">
                    <p>31-May-23</p>
                </td>
                <td colspan="3" width="260">
                    <p>[&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ] COPY OF QUOTATION VENDOR</p>
                </td>
            </tr>
            <tr>
                <td width="83">
                    <p>Due Date (days)</p>
                </td>
                <td width="24">
                    <p>1</p>
                </td>
                <td width="90">
                    <p>01-Jun-23</p>
                </td>
                <td colspan="2" width="118">
                    <p>INVOICE RECEIPT ON</p>
                </td>
                <td width="90">
                    <p>31-May-23</p>
                </td>
                <td colspan="3" width="260">
                    <p>[&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ] COPY OF PURCHASE ORDER</p>
                </td>
            </tr>
            <tr>
                <td colspan="2" width="107">
                    <p>PREPARED BY</p>
                </td>
                <td width="90">
                    <p>CHECKED BY</p>
                </td>
                <td rowspan="5" width="93">
                    <p>&nbsp;</p>
                </td>
                <td colspan="2" width="116">
                    <p>APPROVED BY</p>
                </td>
                <td colspan="3" width="260">
                    <p>[&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ] COPY OF CONTRACT DOCUMENT</p>
                </td>
            </tr>
            <tr>
                <td colspan="2" rowspan="4" width="107">
                    <p>&nbsp;</p>
                    <p>&nbsp;</p>
                    <p>&nbsp;</p>
                    <p>&nbsp;</p>
                    <p>&nbsp;</p>
                    <p>Khouw Vivi</p>
                </td>
                <td rowspan="4" width="90">
                    <p>&nbsp;</p>
                    <p>&nbsp;</p>
                    <p>&nbsp;</p>
                    <p>&nbsp;</p>
                    <p>&nbsp;</p>
                    <p>Djajadi</p>
                </td>
                <td colspan="2" rowspan="4" width="116">
                    <p>&nbsp;</p>
                    <p>&nbsp;</p>
                    <p>&nbsp;</p>
                    <p>&nbsp;</p>
                    <p>&nbsp;</p>
                    <p>Darren Chan</p>
                </td>
                <td colspan="3" width="260">
                    <p>[&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ] COPY OF SURAT PENUNJUKKAN REKANAN</p>
                </td>
            </tr>
            <tr>
                <td colspan="3" width="260">
                    <p>[&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ] ORIGINAL RECEIPT / SURAT JALAN</p>
                </td>
            </tr>
            <tr>
                <td colspan="3" width="260">
                    <p>[&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ] HANDING OVER DOCUMENT ORIGINAL / BAST</p>
                </td>
            </tr>
            <tr>
                <td colspan="3" width="260">
                    <p>[&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ] ORIGINAL BANK GUARANTEE (Down Payment)</p>
                    <p>&nbsp;</p>
                </td>
            </tr>
        </tbody>
    </table>

</body>

</html>
