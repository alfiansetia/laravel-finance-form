<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <table style="margin-left:6.4pt;border-collapse:collapse;border:none;">
        <tbody>
            <tr>
                <td colspan="9"
                    style="width: 499.6pt;border-top: 1pt solid black;border-right: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-bottom: none;padding: 0mm;height: 70pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:.4pt;'><sub><span
                                style="font-size:31px;">&shy;</span></sub><span style="font-size:31px;">&nbsp;<img
                                src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAoHBwkHBgoJCAkLCwoMDxkQDw4ODx4WFxIZJCAmJSMgIyIoLTkwKCo2KyIjMkQyNjs9QEBAJjBGS0U+Sjk/QD3/2wBDAQsLCw8NDx0QEB09KSMpPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT3/wAARCAAtAHIDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD2R3WNCzsFVRkknAArifEPxP0zTN8Omj7fcjjKnESn3bv+H51j+M9P1vXy7Wt+Zbcf8uX3AP8A4r8a89j0u+lvhZR2c7XWceSEO78vT3rvo4aD1mzgq4qW0F8zQ1Txhrer3a3E9/LGUbdGkLFFQ+wH8zXT+Hvitd2u2DW4vtUQ48+MASD6jo36UulfCS9ubRpNSvEtZWX5IkXeQf8AaPT8q5nX/B2reHWJvLcvbg8XEXzIfr6fjW/7ip7mhj+/p++z3DSdc0/XLcTaddRzL/EAcMv1HUVoV8+6PpepRldRjuP7MhTkXcjlPyHVvpXr/gvXxr2mSkTvcm2k8pp3jCGU4BzgdOtcFelGm7J3PQoSqVIc7jp36HR0VzXjzxXJ4N8PDUorVblvOWLy2faOQec4PpXnI+Pt6wyvh+Ij2uG/+JrA1Pa6K4T4e/ES48bXl7BPpi2Yto1cMJC27Jx3Aqr43+Ltn4Xv302xtft19H/rSX2xxn0J6k+360Aei0V4vZfHm7iukXVtCVYW7wuVYD1Abr+Yr0jxF4o/sbwZNr8Fq0gSNJFhmzG2GIGD3B5oA6CivFY/j1fy58vw6jgdds7HH/jtbfhr43adq+oRWWqWL6fJKwRZRJvj3HoDwCKAPT6KTmigDiG++31re0SIy2rTK5SYMV34zkeh9awW++31Na2janDaxGGbK7m3B+1ejXi3DQ8jCyUamrNg3MkJCzREsxwpj5DH+n4/nSmKW4BE5CRnrGvOR7n/AAomdZPs7IwZTKMEH2NY/iDxtpHhwMlzP5tyBxbw/M/49h+Nee9D2IQlUdoq54jrt5cXmsXX2mZ5PLmdEDHhQGIAA7V6b8Hf+QDf/wDX1/7KK8nupvtN5POF2iWRnx6ZJOP1r1j4O/8AIBv/APr6/wDZRULc9/HxUcNZeQ344f8AIgj/AK/I/wCTV5t4F+JyeC9GmsG0kXhknM3mebsxkAYxtPpXpPxw/wCRBH/X5H/Jq4D4d/EHQ/CmgzWWq6fNczPcGVXSJGAUqoxkkHsao8A9a8A+L08aaPPfrYiz8qcw7A+/OADnOB6143480DV/CPjufWhbma2e6N3BOyb4yS27a3oQeMGvW/BXxB0fxZfT2Wk2VxbNDH5zeZGqqRkD+Ennmua1H42W1j4kvNPvdHmbToz5e4jEpI6ko3GD2HBoEVtL+Muh60YIfFOjpEyOGWYIJY1YHhsH5l/DNdZ8T7iK6+F2pz28iywyxxujochgXXBBrxjx/rXhrXr+2k8MaXJaSHPnnYEEhOMAICRnrz716LqOm3mk/s9PaagGW4WFWKN1QNKCFP0BFAzlPhL430fwhb6omryyo1w0ZjEcRfOA2en1FYnim9j8e+P9/h6ydPtJSONdoDOR1dgOn+AroPhH4Q0nxXpetx6pbCSRNiQy5IaLcG5HPsDz6VmeEdVuPhn8QprPVFAh3/Zrk4/hJysg9uh+hoA+jIUMcKIzbiqgE+tFKjiRFdCGVhkEHIIooEY154fViXtW2k87G6fgaxZ7eW2fZMhRvfvXa1HLDHOhSVFdT2Irop4mUdJanHVwkJax0ZweqXE1v4d1N4ZXjZYCylGwQcHkV5Dyzd2Zj9STXvmseG4rmwubWKdoluk8vJXdsz3FHh7wPo/hwK9vB510OtxN8zfh2H4VnXanK6PWyvELCUJRmru55n4e+GmrazsmvB9gtTzukH7xh7L/AI16x4e8OWXhmwNrYB9rNvd3bLO2MZ/TtWrS1lawYjF1K+knp2KmpaVY6xa/ZtStYbqDcG8uVQy5HQ4rJ/4QLwt/0ANO/wC/C10NFM5TL0vw1o+izPNpem2tpI67WaGMKSOuOKXVvDej65j+1NNtrojo0kYLD6HrWnRQBh6Z4L8PaNcCfT9ItIZh92QJll+hOcVqX1ha6laSWt9BHcW8mN8ci5Vuc8irFFAGfpehaXoiyLpdhb2glILiFAu7HTOPrUOpeFtE1i6+06lpVndT7QvmSxBmwOgzWtRQBXhsLa3gjhhhVIo1CIi8BQBgAUVYooA//9k="
                                width="114" height="45"></span></p>
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:.05pt;margin-right:0mm;margin-bottom:.0001pt;margin-left:44.65pt;'>
                        <strong><span style="font-size:21px;">PT. ESR INDONESIA MANAGEMENT</span></strong><strong><span
                                style="font-size:19px;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                                &nbsp;</span></strong><span
                            style='font-size:24px;font-family:"Times New Roman",serif;'>PAYMENT&nbsp;REQUEST</span>
                    </p>
                </td>
            </tr>
            <tr>
                <td
                    style="width: 62.4pt;border-top: none;border-right: none;border-bottom: none;border-image: initial;border-left: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:1.5pt;margin-right:0mm;margin-bottom:.0001pt;margin-left:8.7pt;'>
                        <strong><span style="font-size:11px;">PAID TO :&nbsp;</span></strong>
                    </p>
                </td>
                <td style="width: 18.2pt;border: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td style="width: 67.2pt;border: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td style="width: 69.4pt;border: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td style="width: 19.2pt;border: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td style="width: 67.85pt;border: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 73.05pt;border-top: none;border-bottom: none;border-left: none;border-image: initial;border-right: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 46.25pt;border-top: 1pt solid black;border-right: 1pt solid black;border-bottom: 1pt solid black;border-image: initial;border-left: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:1.5pt;margin-right:0mm;margin-bottom:.0001pt;margin-left:1.5pt;'>
                        <span style="font-size:11px;">NO</span>
                    </p>
                </td>
                <td
                    style="width: 76.05pt;border-top: 1pt solid black;border-right: 1pt solid black;border-bottom: 1pt solid black;border-image: initial;border-left: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:1.5pt;margin-right:  2.05pt;margin-bottom:.0001pt;margin-left:0mm;text-align:  right;'>
                        <span style="font-size:11px;">00001/EIM-PR/06/23&nbsp;</span>
                    </p>
                </td>
            </tr>
            <tr>
                <td
                    style="width: 62.4pt;border-top: none;border-right: none;border-bottom: none;border-image: initial;border-left: 1pt solid black;padding: 0mm;height: 3pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:1.5pt;margin-right:0mm;margin-bottom:.0001pt;margin-left:8.7pt;'>
                        <strong><span style="font-size:11px;">vds</span></strong>
                    </p>
                </td>
                <td style="width: 18.2pt;border: none;padding: 0mm;height: 3pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td style="width: 67.2pt;border: none;padding: 0mm;height: 3pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td style="width: 69.4pt;border: none;padding: 0mm;height: 3pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td style="width: 19.2pt;border: none;padding: 0mm;height: 3pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td style="width: 67.85pt;border: none;padding: 0mm;height: 3pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 73.05pt;border-top: none;border-bottom: none;border-left: none;border-image: initial;border-right: 1pt solid black;padding: 0mm;height: 3pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 46.25pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 3pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:1.5pt;margin-right:0mm;margin-bottom:.0001pt;margin-left:1.5pt;'>
                        <span style="font-size:11px;">DATE</span>
                    </p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 3pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:1.5pt;margin-right:  2.05pt;margin-bottom:.0001pt;margin-left:0mm;text-align:  right;'>
                        <span style="font-size:11px;">06-Jun-23</span>
                    </p>
                </td>
            </tr>
            <tr>
                <td colspan="9"
                    style="width: 499.6pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:1.5pt;margin-right:0mm;margin-bottom:.0001pt;margin-left:8.7pt;'>
                        <strong><span style="font-size:11px;">FOR&nbsp;:&nbsp;eewf</span></strong>
                    </p>
                </td>
            </tr>
            <tr>
                <td colspan="8"
                    style="width: 423.55pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:1.5pt;text-align:center;'>
                        <strong><span style="font-size:11px;">DESCRIPTION</span></strong>
                    </p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:1.5pt;margin-right:  2.75pt;margin-bottom:.0001pt;margin-left:0mm;text-align:  center;'>
                        <strong><span style="font-size:11px;">AMOUNT</span></strong>
                    </p>
                </td>
            </tr>
            <tr>
                <td colspan="8"
                    style="width: 423.55pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;sdfdsf</span></p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:1.5pt;margin-right:  2.75pt;margin-bottom:.0001pt;margin-left:0mm;text-align:  right;'>
                        <span style="font-size:11px;">Rp1&nbsp;</span>
                    </p>
                </td>
            </tr>
            <tr>
                <td colspan="8"
                    style="width: 423.55pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;asfa</span></p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:1.5pt;margin-right:  2.75pt;margin-bottom:.0001pt;margin-left:0mm;text-align:  right;'>
                        <span style="font-size:11px;">Rp2&nbsp;</span>
                    </p>
                </td>
            </tr>
            <tr>
                <td colspan="8"
                    style="width: 423.55pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;sf</span></p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:1.5pt;margin-right:  2.75pt;margin-bottom:.0001pt;margin-left:0mm;text-align:  right;'>
                        <span style="font-size:11px;">Rp3&nbsp;</span>
                    </p>
                </td>
            </tr>
            <tr>
                <td colspan="8"
                    style="width: 423.55pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;&nbsp;</span></p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-right:1.75pt;text-align:  right;'>
                        <span style="font-size:11px;">&nbsp; &nbsp; &nbsp;&nbsp;</span>
                    </p>
                </td>
            </tr>
            <tr>
                <td colspan="8"
                    style="width: 423.55pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;&nbsp;</span></p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-right:1.75pt;text-align:  right;'>
                        <span style="font-size:11px;">&nbsp;</span>
                    </p>
                </td>
            </tr>
            <tr>
                <td colspan="8"
                    style="width: 423.55pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
            </tr>
            <tr>
                <td colspan="8"
                    style="width: 423.55pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
            </tr>
            <tr>
                <td colspan="8"
                    style="width: 423.55pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
            </tr>
            <tr>
                <td colspan="8"
                    style="width: 423.55pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
            </tr>
            <tr>
                <td colspan="8"
                    style="width: 423.55pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
            </tr>
            <tr>
                <td colspan="8"
                    style="width: 423.55pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
            </tr>
            <tr>
                <td colspan="8"
                    style="width: 423.55pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
            </tr>
            <tr>
                <td colspan="8"
                    style="width: 423.55pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
            </tr>
            <tr>
                <td colspan="8"
                    style="width: 423.55pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
            </tr>
            <tr>
                <td colspan="8"
                    style="width: 423.55pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
            </tr>
            <tr>
                <td colspan="8"
                    style="width: 423.55pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
            </tr>
            <tr>
                <td colspan="8"
                    style="width: 423.55pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
            </tr>
            <tr>
                <td colspan="8"
                    style="width: 423.55pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
            </tr>
            <tr>
                <td colspan="8"
                    style="width: 423.55pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
            </tr>
            <tr>
                <td colspan="8"
                    style="width: 423.55pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
            </tr>
            <tr>
                <td colspan="8"
                    style="width: 423.55pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
            </tr>
            <tr>
                <td colspan="8"
                    style="width: 423.55pt;border-top: none;border-left: 1pt solid black;border-bottom: 1.5pt solid black;border-right: 1pt solid black;padding: 0mm;height: 12.85pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1.5pt solid black;border-right: 1pt solid black;padding: 0mm;height: 12.85pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
            </tr>
            <tr>
                <td
                    style="width: 62.4pt;border-top: none;border-right: none;border-bottom: none;border-image: initial;border-left: 1pt solid black;padding: 0mm;height: 12.6pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td style="width: 18.2pt;border: none;padding: 0mm;height: 12.6pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td style="width: 67.2pt;border: none;padding: 0mm;height: 12.6pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td style="width: 69.4pt;border: none;padding: 0mm;height: 12.6pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td style="width: 19.2pt;border: none;padding: 0mm;height: 12.6pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td style="width: 67.85pt;border: none;padding: 0mm;height: 12.6pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td style="width: 73.05pt;border: none;padding: 0mm;height: 12.6pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 46.25pt;border-top: none;border-bottom: none;border-left: none;border-image: initial;border-right: 1pt solid black;padding: 0mm;height: 12.6pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:1.15pt;text-indent:5.0pt;'>
                        <strong><span style="font-size:11px;">To be Paid&nbsp;</span></strong>
                    </p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 12.6pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:1.15pt;margin-right:  2.8pt;margin-bottom:.0001pt;margin-left:0mm;text-align:  right;'>
                        <strong><span style="font-size:11px;">Rp7</span></strong>
                    </p>
                </td>
            </tr>
            <tr>
                <td
                    style="width: 62.4pt;border-top: none;border-right: none;border-bottom: none;border-image: initial;border-left: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td style="width: 18.2pt;border: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td style="width: 67.2pt;border: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td style="width: 69.4pt;border: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td style="width: 19.2pt;border: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td style="width: 67.85pt;border: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td style="width: 73.05pt;border: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 46.25pt;border-top: none;border-bottom: none;border-left: none;border-image: initial;border-right: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:1.5pt;margin-right:0mm;margin-bottom:.0001pt;margin-left:18.2pt;text-indent:-4.3pt;'>
                        <strong><span style="font-size:11px;">Forex&nbsp;at</span></strong>
                    </p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
            </tr>
            <tr>
                <td
                    style="width: 62.4pt;border-top: none;border-right: none;border-bottom: none;border-image: initial;border-left: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td style="width: 18.2pt;border: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td style="width: 67.2pt;border: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td style="width: 69.4pt;border: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td style="width: 19.2pt;border: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td style="width: 67.85pt;border: none;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td colspan="2"
                    style="width: 119.3pt;border-top: none;border-bottom: none;border-left: none;border-image: initial;border-right: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:1.5pt;margin-right:0mm;margin-bottom:.0001pt;margin-left:72.45pt;text-indent:5.55pt;'>
                        <strong><span style="font-size:11px;">Convert&nbsp;to</span></strong>
                    </p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 13pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
            </tr>
            <tr>
                <td
                    style="width: 62.4pt;border-top: none;border-left: 1pt solid black;border-bottom: 1.5pt solid black;border-right: none;padding: 0mm;height: 12.8pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 18.2pt;border-top: none;border-right: none;border-left: none;border-image: initial;border-bottom: 1.5pt solid black;padding: 0mm;height: 12.8pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 67.2pt;border-top: none;border-right: none;border-left: none;border-image: initial;border-bottom: 1.5pt solid black;padding: 0mm;height: 12.8pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 69.4pt;border-top: none;border-right: none;border-left: none;border-image: initial;border-bottom: 1.5pt solid black;padding: 0mm;height: 12.8pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 19.2pt;border-top: none;border-right: none;border-left: none;border-image: initial;border-bottom: 1.5pt solid black;padding: 0mm;height: 12.8pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 67.85pt;border-top: none;border-right: none;border-left: none;border-image: initial;border-bottom: 1.5pt solid black;padding: 0mm;height: 12.8pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td colspan="2"
                    style="width: 119.3pt;border-top: none;border-left: none;border-bottom: 1.5pt solid black;border-right: 1pt solid black;padding: 0mm;height: 12.8pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:1.5pt;margin-right:0mm;margin-bottom:.0001pt;margin-left:63.25pt;text-indent:2.4pt;'>
                        <strong><span style="font-size:11px;">&nbsp;Bank Charges&nbsp;</span></strong>
                    </p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 1.5pt solid black;border-right: 1pt solid black;padding: 0mm;height: 12.8pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:1.5pt;margin-right:  2.8pt;margin-bottom:.0001pt;margin-left:0mm;text-align:  right;'>
                        <strong><span style="font-size:11px;">Rp1</span></strong>
                    </p>
                </td>
            </tr>
            <tr>
                <td colspan="8"
                    style="width: 423.55pt;border-top: none;border-left: 1pt solid black;border-bottom: 3pt solid black;border-right: 1pt solid black;padding: 0mm;height: 12.65pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:1.15pt;margin-right:  3.75pt;margin-bottom:.0001pt;margin-left:0mm;text-align:  right;'>
                        <strong><span style="font-size:11px;">TOTAL &nbsp;</span></strong>
                    </p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-left: none;border-bottom: 3pt solid black;border-right: 1pt solid black;padding: 0mm;height: 12.65pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:1.15pt;margin-right:  2.8pt;margin-bottom:.0001pt;margin-left:0mm;text-align:  right;'>
                        <strong><span style="font-size:11px;">Rp8</span></strong>
                    </p>
                </td>
            </tr>
            <tr>
                <td colspan="9"
                    style="width: 499.6pt;border-top: none;border-left: 1pt solid black;border-bottom: 1.5pt double black;border-right: 1pt solid black;padding: 0mm;height: 9.6pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:8px;">&nbsp;</span></p>
                </td>
            </tr>
            <tr>
                <td colspan="3"
                    style="width: 147.8pt;border-top: none;border-left: 1pt solid black;border-bottom: none;border-right: 1pt solid black;padding: 0mm;height: 11.6pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:1.9pt;margin-right:0mm;margin-bottom:.0001pt;margin-left:8.7pt;line-height:8.7pt;'>
                        <strong><u><span style="font-size:11px;">BANK ACCOUNT
                                    FROM&nbsp;</span></u></strong><strong><span
                                style="font-size:11px;">:</span></strong>
                    </p>
                </td>
                <td colspan="3"
                    style="width: 156.45pt;border-top: none;border-bottom: none;border-left: none;border-image: initial;border-right: 1pt solid black;padding: 0mm;height: 11.6pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:1.9pt;margin-right:0mm;margin-bottom:.0001pt;margin-left:8.7pt;line-height:8.7pt;'>
                        <strong><u><span style="font-size:11px;">TRANSFERRED TO BANK
                                    ACCOUNT&nbsp;</span></u></strong><strong><span
                                style="font-size:11px;">:</span></strong>
                    </p>
                </td>
                <td colspan="3"
                    style="width: 195.35pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 11.6pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:1.9pt;margin-right:0mm;margin-bottom:.0001pt;margin-left:1.55pt;line-height:8.7pt;'>
                        <strong><span style="font-size:11px;">CHECK&nbsp;SUPPORTING&nbsp;DOCUMENT</span></strong>
                    </p>
                </td>
            </tr>
            <tr>
                <td colspan="3"
                    style="width: 147.8pt;border-top: none;border-left: 1pt solid black;border-bottom: none;border-right: 1pt solid black;padding: 0mm;height: 9.55pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-left:8.7pt;line-height:9.65pt;'>
                        <span style="font-size:11px;">dsfsd</span>
                    </p>
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;text-indent:8.0pt;line-height:8.6pt;'>
                        <span style="font-size:11px;">PT. ESR INDONESIA MANAGEMENT</span>
                    </p>
                </td>
                <td colspan="3"
                    style="width: 156.45pt;border-top: none;border-bottom: none;border-left: none;border-image: initial;border-right: 1pt solid black;padding: 0mm;height: 9.55pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-left:8.7pt;line-height:8.6pt;'>
                        <span style="font-size:11px;">vds</span>
                    </p>
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-left:8.7pt;line-height:8.6pt;'>
                        <span style="font-size:11px;">sdd</span>
                    </p>
                </td>
                <td
                    style="width: 73.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 9.55pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-left:1.55pt;line-height:8.6pt;'>
                        <strong><span style="font-size:11px;">CONTRACT&nbsp;/&nbsp;PO&nbsp;No</span></strong>
                    </p>
                </td>
                <td colspan="2"
                    style="width: 122.3pt;border-top: 1pt solid black;border-right: 1pt solid black;border-bottom: 1pt solid black;border-image: initial;border-left: none;padding: 0mm;height: 9.55pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:8px;">&nbsp;${Contract+po}</span></p>
                </td>
            </tr>
            <tr>
                <td colspan="3"
                    style="width: 147.8pt;border-top: none;border-left: 1pt solid black;border-bottom: none;border-right: 1pt solid black;padding: 0mm;height: 11pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-left:8.7pt;line-height:9.65pt;'>
                        <span style="font-size:11px;">&nbsp;</span>
                    </p>
                </td>
                <td style="width: 69.4pt;border: none;padding: 0mm;height: 11pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-left:8.7pt;line-height:9.65pt;'>
                        <span style="font-size:11px;">&nbsp;</span>
                    </p>
                </td>
                <td style="width: 19.2pt;border: none;padding: 0mm;height: 11pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:9px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 67.85pt;border-top: none;border-bottom: none;border-left: none;border-image: initial;border-right: 1pt solid black;padding: 0mm;height: 11pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:9px;">&nbsp;</span></p>
                </td>
                <td colspan="3"
                    style="width: 195.35pt;border-top: none;border-bottom: none;border-left: none;border-image: initial;border-right: 1pt solid black;padding: 0mm;height: 11pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-left:8.7pt;line-height:9.65pt;'>
                        <span style="font-size:11px;">[ &nbsp; &nbsp; &nbsp;] ORIGINAL INVOICE + MATERAI</span>
                    </p>
                </td>
            </tr>
            <tr>
                <td colspan="3"
                    style="width: 147.8pt;border-top: none;border-left: 1pt solid black;border-bottom: none;border-right: 1pt solid black;padding: 0mm;height: 10.6pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:9px;">&nbsp;</span></p>
                </td>
                <td style="width: 69.4pt;border: none;padding: 0mm;height: 10.6pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:9px;">&nbsp;</span></p>
                </td>
                <td style="width: 19.2pt;border: none;padding: 0mm;height: 10.6pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:9px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 67.85pt;border-top: none;border-bottom: none;border-left: none;border-image: initial;border-right: 1pt solid black;padding: 0mm;height: 10.6pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:9px;">&nbsp;</span></p>
                </td>
                <td colspan="2"
                    style="width: 119.3pt;border: none;padding: 0mm;height: 10.6pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-left:8.7pt;line-height:9.25pt;'>
                        <span style="font-size:11px;">[ &nbsp; &nbsp; &nbsp;] ORIGINAL FAKTUR PAJAK</span>
                    </p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-bottom: none;border-left: none;border-image: initial;border-right: 1pt solid black;padding: 0mm;height: 10.6pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:9px;">&nbsp;</span></p>
                </td>
            </tr>
            <tr>
                <td colspan="3"
                    style="width: 147.8pt;border-top: none;border-left: 1pt solid black;border-bottom: none;border-right: 1pt solid black;padding: 0mm;height: 10.55pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:9px;">&nbsp;</span></p>
                </td>
                <td style="width: 69.4pt;border: none;padding: 0mm;height: 10.55pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:9px;">&nbsp;</span></p>
                </td>
                <td style="width: 19.2pt;border: none;padding: 0mm;height: 10.55pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:9px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 67.85pt;border-top: none;border-bottom: none;border-left: none;border-image: initial;border-right: 1pt solid black;padding: 0mm;height: 10.55pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:9px;">&nbsp;</span></p>
                </td>
                <td colspan="3"
                    style="width: 195.35pt;border-top: none;border-bottom: none;border-left: none;border-image: initial;border-right: 1pt solid black;padding: 0mm;height: 10.55pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-left:8.7pt;line-height:9.25pt;'>
                        <span style="font-size:11px;">[ &nbsp; &nbsp; &nbsp;] ORIGINAL DGT-1 WP LN ( Foreigner
                            Consultant )</span>
                    </p>
                </td>
            </tr>
            <tr>
                <td colspan="3"
                    style="width: 147.8pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 9.2pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:8px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 69.4pt;border-top: none;border-right: none;border-left: none;border-image: initial;border-bottom: 1pt solid black;padding: 0mm;height: 9.2pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:8px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 19.2pt;border-top: none;border-right: none;border-left: none;border-image: initial;border-bottom: 1pt solid black;padding: 0mm;height: 9.2pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:8px;">&nbsp;</span></p>
                </td>
                <td
                    style="width: 67.85pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 9.2pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:8px;">&nbsp;</span></p>
                </td>
                <td colspan="2"
                    style="width: 119.3pt;border: none;padding: 0mm;height: 9.2pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-left:8.7pt;line-height:8.2pt;'>
                        <span style="font-size:11px;">[ &nbsp; &nbsp; &nbsp;] COPY OF NPWP</span>
                    </p>
                </td>
                <td
                    style="width: 76.05pt;border-top: none;border-bottom: none;border-left: none;border-image: initial;border-right: 1pt solid black;padding: 0mm;height: 9.2pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:8px;">&nbsp;</span></p>
                </td>
            </tr>
            <tr>
                <td colspan="2"
                    style="width: 80.6pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 9.55pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-left:1.5pt;line-height:8.6pt;'>
                        <span style="font-size:11px;">Paid&nbsp;by</span>
                    </p>
                </td>
                <td
                    style="width: 67.2pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 9.55pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:0mm;margin-right:4.15pt;margin-bottom:.0001pt;margin-left:6.1pt;text-align:center;line-height:8.6pt;'>
                        <span style="font-size:11px;">Internet&nbsp;Banking</span>
                    </p>
                </td>
                <td colspan="2"
                    style="width: 88.6pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 9.55pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-left:8.7pt;line-height:8.6pt;'>
                        <span style="font-size:11px;">INVOICE DATE</span>
                    </p>
                </td>
                <td
                    style="width: 67.85pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 9.55pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-left:18.35pt;line-height:8.6pt;'>
                        <span style="font-size:11px;">06-Jun-23</span>
                    </p>
                </td>
                <td colspan="3"
                    style="width: 195.35pt;border-top: none;border-bottom: none;border-left: none;border-image: initial;border-right: 1pt solid black;padding: 0mm;height: 9.55pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-left:8.7pt;line-height:8.6pt;'>
                        <span style="font-size:11px;">[ &nbsp; &nbsp; &nbsp;] COPY OF QUOTATION VENDOR</span>
                    </p>
                </td>
            </tr>
            <tr>
                <td
                    style="width: 62.4pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 9.6pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-left:1.5pt;line-height:8.6pt;'>
                        <span style="font-size:11px;">Due&nbsp;Date&nbsp;(days)</span>
                    </p>
                </td>
                <td
                    style="width: 18.2pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 9.6pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-left:7.5pt;line-height:8.6pt;'>
                        <span style="font-size:11px;">&nbsp;</span>
                    </p>
                </td>
                <td
                    style="width: 67.2pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 9.6pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:0mm;margin-right:4.15pt;margin-bottom:.0001pt;margin-left:5.9pt;text-align:center;line-height:8.6pt;'>
                        <span style="font-size:11px;">06-Jun-23</span>
                    </p>
                </td>
                <td colspan="2"
                    style="width: 88.6pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 9.6pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-left:8.7pt;line-height:8.6pt;'>
                        <span style="font-size:11px;">INVOICE&nbsp;RECEIPT&nbsp;ON</span>
                    </p>
                </td>
                <td
                    style="width: 67.85pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 9.6pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-left:18.35pt;line-height:8.6pt;'>
                        <span style="font-size:11px;">06-Jun-23</span>
                    </p>
                </td>
                <td colspan="3"
                    style="width: 195.35pt;border-top: none;border-bottom: none;border-left: none;border-image: initial;border-right: 1pt solid black;padding: 0mm;height: 9.6pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-left:8.7pt;line-height:8.6pt;'>
                        <span style="font-size:11px;">[ &nbsp; &nbsp; &nbsp;] COPY OF PURCHASE ORDER</span>
                    </p>
                </td>
            </tr>
            <tr>
                <td colspan="2"
                    style="width: 80.6pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 13.4pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:3.7pt;margin-right:0mm;margin-bottom:.0001pt;margin-left:18.3pt;line-height:8.7pt;'>
                        <span style="font-size:11px;">PREPARED&nbsp;BY</span>
                    </p>
                </td>
                <td
                    style="width: 67.2pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 13.4pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:3.7pt;margin-right:  4.15pt;margin-bottom:.0001pt;margin-left:6.05pt;text-align:  center;line-height:8.7pt;'>
                        <span style="font-size:11px;">CHECKED BY</span>
                    </p>
                </td>
                <td rowspan="5"
                    style="width: 69.4pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 13.4pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                </td>
                <td colspan="2"
                    style="width: 87.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 13.4pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:3.7pt;margin-right:0mm;margin-bottom:.0001pt;margin-left:20.75pt;line-height:8.7pt;'>
                        <span style="font-size:11px;">APPROVED&nbsp;BY</span>
                    </p>
                </td>
                <td colspan="3"
                    style="width: 195.35pt;border-top: none;border-bottom: none;border-left: none;border-image: initial;border-right: 1pt solid black;padding: 0mm;height: 13.4pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:3.7pt;margin-right:0mm;margin-bottom:.0001pt;margin-left:8.7pt;line-height:8.7pt;'>
                        <span style="font-size:11px;">[ &nbsp; &nbsp; &nbsp;] COPY OF CONTRACT DOCUMENT</span>
                    </p>
                </td>
            </tr>
            <tr>
                <td colspan="2" rowspan="4"
                    style="width: 80.6pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0mm;height: 10.45pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:6.9pt;margin-right:0mm;margin-bottom:.0001pt;margin-left:22.7pt;line-height:8.7pt;'>
                        <span style="font-size:11px;">Khouw&nbsp;Vivi</span>
                    </p>
                </td>
                <td rowspan="4"
                    style="width: 67.2pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 10.45pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:6.9pt;margin-right:0mm;margin-bottom:.0001pt;margin-left:22.7pt;line-height:8.7pt;'>
                        <span style="font-size:11px;">Djajadi</span>
                    </p>
                </td>
                <td colspan="2" rowspan="4"
                    style="width: 87.05pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 10.45pt;vertical-align: top;">
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><span
                            style="font-size:11px;">&nbsp;</span></p>
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:6.9pt;margin-right:0mm;margin-bottom:.0001pt;margin-left:23.55pt;line-height:8.7pt;'>
                        <span style="font-size:11px;">Darren&nbsp;Chan</span>
                    </p>
                </td>
                <td colspan="3"
                    style="width: 195.35pt;border-top: none;border-bottom: none;border-left: none;border-image: initial;border-right: 1pt solid black;padding: 0mm;height: 10.45pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-left:8.7pt;line-height:9.5pt;'>
                        <span style="font-size:11px;">[ &nbsp; &nbsp; &nbsp;] COPY OF SURAT PENUNJUKKAN REKANAN</span>
                    </p>
                </td>
            </tr>
            <tr>
                <td colspan="3"
                    style="width: 195.35pt;border-top: none;border-bottom: none;border-left: none;border-image: initial;border-right: 1pt solid black;padding: 0mm;height: 9.55pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-left:8.7pt;line-height:8.6pt;'>
                        <span style="font-size:11px;">[ &nbsp; &nbsp; &nbsp;] ORIGINAL RECEIPT / SURAT JALAN</span>
                    </p>
                </td>
            </tr>
            <tr>
                <td colspan="3"
                    style="width: 195.35pt;border-top: none;border-bottom: none;border-left: none;border-image: initial;border-right: 1pt solid black;padding: 0mm;height: 9.6pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-left:8.7pt;line-height:8.6pt;'>
                        <span style="font-size:11px;">[ &nbsp; &nbsp; &nbsp;] HANDING OVER DOCUMENT ORIGINAL /
                            BAST</span>
                    </p>
                </td>
            </tr>
            <tr>
                <td colspan="3"
                    style="width: 195.35pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0mm;height: 29.85pt;vertical-align: top;">
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-left:8.7pt;line-height:8.75pt;'>
                        <span style="font-size:11px;">[ &nbsp; &nbsp; &nbsp;] ORIGINAL BANK GUARANTEE (Down
                            Payment)</span>
                    </p>
                    <p
                        style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;margin-left:8.7pt;line-height:8.75pt;'>
                        <span style="font-size:11px;">&nbsp;</span>
                    </p>
                </td>
            </tr>
        </tbody>
    </table>
    <p style='margin:0mm;font-size:15px;font-family:"Calibri",sans-serif;'><br></p>
</body>

</html>
